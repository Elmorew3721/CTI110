user_num = int(4)

print(user_num*user_num)
print(user_num*user_num*user_num)

user_num2= int(5)
print(user_num2 + user_num)
print(user_num2 * user_num)