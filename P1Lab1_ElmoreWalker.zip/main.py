userNum = int(3)
userNumSquared = userNum * userNum   
   
print(userNumSquared, end='')      